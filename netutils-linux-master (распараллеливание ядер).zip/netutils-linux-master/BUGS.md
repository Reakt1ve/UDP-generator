These "bugs" will never be fixed:

- No `bridge` util in CentOS 6.4 (`iproute-2.6.32-23.el6.x86_64`). Solution: `yum -y install iproute`
