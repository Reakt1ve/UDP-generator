# Core development team:

- [@strizhechenko](https://github.com/strizhechenko)
