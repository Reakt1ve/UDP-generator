# Tested on

python | distro | kernel
--- | --- | ---
Python 2.7 | Ubuntu 16.10 | Linux 4.4.0-72-generic #93-Ubuntu SMP
Python 2.6 | CentOS 6.8 | Linux 2.6.32 696
Python 2.7 | CentOS 7.3 | Linux 3.10
