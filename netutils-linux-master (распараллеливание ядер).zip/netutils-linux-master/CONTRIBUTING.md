I'm very welcome any help with this project. I'm usually place label [help wanted](https://github.com/strizhechenko/netutils-linux/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22) to tasks that may be a good start to contribute. You also may help with codebase cleanup by fixing some issues on [codeclimate](https://codeclimate.com/github/strizhechenko/netutils-linux/issues).

About pull requests: just use common sense and run `make test` in virtualenv before submit.

You also may help with your success story / usage example in [examples directory](https://github.com/strizhechenko/netutils-linux/tree/master/examples).
