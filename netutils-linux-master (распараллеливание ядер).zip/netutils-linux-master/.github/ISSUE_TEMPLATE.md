If you encountered some bug/error in one of these utils, please, provide following information:

```
python --version
pip show netutils-linux
cat /etc/issue
uname -a
lscpu
lscpu -p
```

and python traceback and (or) `bash -x $utility_you_running`.

if `server-info-collect server` is able to collect /root/server.tar.gz - attaching this archive in issue will speed up debugging very well.
